import json

def lambda_handler(event, context):
    try:
        # Log the incoming event for debugging
        print("Received event:", json.dumps(event))

        # Get the body of the event
        body = json.loads(event['body'])
        
        # Check if the event type is URL verification from Slack
        if body['type'] == 'url_verification':
            # Return the challenge sent by Slack to complete the URL verification
            challenge = body['challenge']
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({'challenge': challenge})
            }

        # If it's not URL verification, return a generic error message
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid event type'})
        }

    except Exception as e:
        # Log the error message
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
